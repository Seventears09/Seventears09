# IceMeme(Ice and MemeHax) Updated!
# By using IceMeme you accept that you wont Sell your exploit in any way


# Go to Release to Download
[Click Here to go to the latest release](https://github.com/rakion99/IceSource/releases/latest)


# Features:

## Tested and Working in Windows 7 32 bits and Windows 10 64 bits

### NEW Feature:

#### Now you can change the tittle and toolbar Exploit name with only changing the dll name

* Fast Scanning
* Windows 7 32 bits support
* Stable
* Very Fast Updates
* Update Checker
* Simple Windows Forms UI/Gui
* Click TP
* GetObjects(only Insert Model ID so its not in Limited Lua for now)
* Works in Non-FE Games

## Lua C Support:

* getglobal
* getfield
* setglobal
* setfield
* pcall
* call
* pushnil
* pushstring
* pushvalue
* pushnumber
* pushboolean
* settop
* pop
* wait(maybe will work maybe not)
* emptystack

## Limited Lua Support:

* idk :P only tested simple scripts


# NOTE: You need to know C++(for the dll), C# for external Ui/Gui and how to use Ida(Interactive DisAssembler) for the address and other stuff
# If you only join to ask how to build the dll, how to fix common and simple errors you will be ignored or just called SKID 

# Make sure you are compiling/Building it in Release x86 and not in x64 and/or Debug or you will have errors

![](https://i.imgur.com/rAER3e5.png)

# Credits:
## rakion99 for updating and improving this :wink:(I made a Discord Server if you want to join or not [IcE StUfF HeLp](https://discord.gg/K2A2Xhv "Click to join"))
## Roblox for making a exploitable game :/
## Jayden
## louka for danghui
## Africaus for pcall bypass
## VOID for getobjects
## tepig for Memehax
## Eternal for RetCheck https://github.com/EternalV3/Retcheck
## AutisticBobby https://youtube.com/c/AutisticBobby
## DOGGO "bypass/workaround for setting values on non-fe games"
<sub> ICE By: Josh() and Cosmology</sub>
## Powered by cURL
![](https://curl.haxx.se/pix/powered_by_curl.gif)
[cURL Site](https://curl.haxx.se/ "Click to enter cURL Site")
## Powered by Lua
![](https://www.lua.org/images/powered-by-lua.gif)
[Lua Site](http://www.lua.org/ "Click to enter Lua Site")
